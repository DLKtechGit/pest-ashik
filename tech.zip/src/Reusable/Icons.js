import React from 'react'
import { FaBeer } from "react-icons/fa";

export const Icons = () => {
  return (
    <div>Icons</div>
  )
}
