const ServicesName = [
    {
        img: require("../../../../../Assets/Images/s1.webp"),
        title:"Crawling Insects",
        index:1
    },
    {
        img: require("../../../../../Assets/Images/s2.webp"),
        title:"Rodent Control",
        index:2
    },
    {
        img: require("../../../../../Assets/Images/s3.webp"),
        title:"Flying Insects",
        index:3
    },
    {
        img: require("../../../../../Assets/Images/s4.webp"),
        title:"Bird Control",
        index:4
    },
    {
        img: require("../../../../../Assets/Images/s5.webp"),
        title:"Snake & Scorpion",
        index:5
    },
    {
        img: require("../../../../../Assets/Images/s6.webp"),
        title:"Termite Control",
        index:6
    },   
]

export { ServicesName };
